# OpenClaw Agent - Complete Docker Deployment Guide

**AI-Powered Autonomous Agent Framework for FloGuru**

Docker Hub: `brandontech/openclaw-agent`

---

## 📦 Quick Start

### 1. Using Docker Hub (Recommended for Production)

```bash
# Simple deployment
docker run -d \
  --name openclaw-agent \
  -p 3000:3000 \
  -e OPENAI_API_KEY="your_key_here" \
  brandontech/openclaw-agent:latest
```

### 2. Using Docker Compose (Full Stack)

```bash
# Clone or download the docker-compose.yml from this gist
# Create .env file with your keys
echo "OPENAI_API_KEY=your_key_here" > .env

# Start all services (OpenClaw + PostgreSQL + Redis)
docker compose up -d

# View logs
docker compose logs -f openclaw

# Stop all services
docker compose down
```

---

## 🏗️ Building from Source

### Build Locally

```bash
# Clone your OpenClaw repo
git clone https://github.com/yourusername/openclaw-agent.git
cd openclaw-agent

# Build with optimized multi-stage Dockerfile
docker build -t openclaw-agent .

# Run locally
docker run -d --name openclaw -p 3000:3000 -e OPENAI_API_KEY="your_key" openclaw-agent
```

### Push to Docker Hub

```bash
# Login to Docker Hub
docker login

# Tag your image
docker tag openclaw-agent brandontech/openclaw-agent:latest
docker tag openclaw-agent brandontech/openclaw-agent:v1.0.0

# Push to Docker Hub
docker push brandontech/openclaw-agent:latest
docker push brandontech/openclaw-agent:v1.0.0
```

---

## ☁️ Deploy to Cloud Platforms

### Railway

1. **Via Docker Hub:**
   - Go to Railway dashboard
   - New Project → Deploy from Docker Hub
   - Image: `brandontech/openclaw-agent:latest`
   - Add environment variables (OPENAI_API_KEY, etc.)
   - Deploy!

2. **Via GitHub:**
   - Connect your GitHub repo
   - Railway auto-detects Dockerfile
   - Add environment variables
   - Push to trigger deployments

### OVH Cloud / VPS

```bash
# SSH into your OVH instance
ssh ubuntu@your-ovh-ip

# Install Docker (if not installed)
curl -fsSL https://get.docker.com | sh

# Pull and run from Docker Hub
docker run -d \
  --name openclaw-agent \
  --restart unless-stopped \
  -p 3000:3000 \
  -v /opt/openclaw/data:/app/data \
  -e OPENAI_API_KEY="your_key" \
  brandontech/openclaw-agent:latest

# Or use docker-compose
wget https://gist.github.com/yourgist/docker-compose.yml
docker compose up -d
```

### Google Cloud Run

```bash
# Deploy directly from Docker Hub
gcloud run deploy openclaw-agent \
  --image docker.io/brandontech/openclaw-agent:latest \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars OPENAI_API_KEY="your_key"
```

---

## 🔧 Configuration

### Environment Variables

```bash
# AI Provider Keys (Required)
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...        # Optional
DEEPSEEK_API_KEY=...                # Optional

# Application
NODE_ENV=production
PORT=3000
LOG_LEVEL=info

# Database (Optional - if using PostgreSQL)
DATABASE_URL=postgresql://user:pass@host:5432/openclaw

# Redis (Optional - if using Redis)
REDIS_URL=redis://host:6379
```

### Volumes (Data Persistence)

```bash
# Local development
-v ./data:/app/data          # Application data
-v ./memory:/app/memory      # Agent memory/state
-v ./logs:/app/logs          # Log files

# Production (named volumes)
-v openclaw-data:/app/data
-v openclaw-memory:/app/memory
```

---

## 📊 Monitoring & Health Checks

```bash
# Check container health
docker ps

# View logs
docker logs -f openclaw-agent

# Health endpoint
curl http://localhost:3000/health

# Stats
docker stats openclaw-agent
```

---

## 🚀 Production Best Practices

1. **Use specific version tags** instead of `latest`
   ```bash
   brandontech/openclaw-agent:v1.0.0
   ```

2. **Set resource limits**
   ```yaml
   deploy:
     resources:
       limits:
         cpus: '2'
         memory: 2G
   ```

3. **Enable health checks** (included in Dockerfile)

4. **Use secrets management**
   - Railway: Environment variables
   - Docker Swarm: Docker secrets
   - Kubernetes: K8s secrets

5. **Enable logging**
   ```yaml
   logging:
     driver: "json-file"
     options:
       max-size: "10m"
       max-file: "3"
   ```

---

## 📁 Project Structure

```
openclaw-agent/
├── Dockerfile              # Multi-stage optimized build
├── docker-compose.yml      # Full stack with DB & Redis
├── .dockerignore          # Exclude unnecessary files
├── package.json
├── src/
│   ├── index.js           # Main entry point
│   └── ...
├── config/
└── data/                  # Persistent data (gitignored)
```

---

## 🐛 Troubleshooting

### Container won't start
```bash
# Check logs
docker logs openclaw-agent

# Inspect container
docker inspect openclaw-agent

# Enter container for debugging
docker exec -it openclaw-agent sh
```

### Port already in use
```bash
# Use different port
docker run -p 3001:3000 ...
```

### Permission issues with volumes
```bash
# Fix ownership (if running as non-root)
sudo chown -R 1001:1001 ./data
```

---

## 📚 Additional Resources

- Docker Hub: https://hub.docker.com/r/brandontech/openclaw-agent
- Railway Docs: https://docs.railway.app/
- Docker Compose Docs: https://docs.docker.com/compose/

---

**Built with ❤️ for FloGuru by Northern Ventures**